package com.anuj.ERP.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDate;

@Data
@Entity
public class Staff implements Users {

    @Id
    @NotNull
    @Min(1000000000L)
    @Max(10000000000L)
    private long sid;

    @NotBlank
    private String name;

    @Email
    @Column(unique = true)
    @NotBlank
    private String email;

    @Past
    private LocalDate dob;

    @NotBlank
    private String password;

    @Column(unique = true)
    @Max(9999999999L)
    @Min(7000000000L)
    @NotNull
    private Long contact;

    @Override
    public long getUserId() {
        return sid;
    }

    @Override
    public String getUserpass() {
        return password;
    }

    @Override
    public String getUserName() {
        return name;
    }
}
