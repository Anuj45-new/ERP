package com.anuj.ERP.serviceimpl;

import com.anuj.ERP.model.Staff;
import com.anuj.ERP.model.Students;
import com.anuj.ERP.repository.StaffRepository;
import com.anuj.ERP.repository.StudentsRepository;
import lombok.Data;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@Data
public class MyUserDetailService implements UserDetailsService {

    private final StudentsRepository studentsRepository;
    private final StaffRepository staffRepository;

    @Override
    public UserDetails loadUserByUsername(String id) throws UsernameNotFoundException {
        Long Id = Long.parseLong(id);
        Students students = studentsRepository.findById(Id).orElse(null);
        Staff staff = staffRepository.findById(Id).orElse(null);

        if(students != null){
            return new UserPrinciple(students);
        }
        else if(staff != null){
            return new UserPrinciple(staff);
        }
        throw new UsernameNotFoundException("No user found");
    }
}
